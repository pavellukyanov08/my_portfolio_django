/** инициализация jQuery**/
$(document).ready(function(){
    $('.feedback').slick({
        arrows:true,
        dots:true,
    });
});